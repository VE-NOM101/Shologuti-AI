"""Game logic primitives for Sixteen - A Game of Tradition."""


