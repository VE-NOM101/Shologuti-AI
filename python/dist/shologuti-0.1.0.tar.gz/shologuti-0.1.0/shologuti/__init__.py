"""Lightweight Sixteen - A Game of Tradition package focused on the Pygame client."""

__all__: list[str] = []

