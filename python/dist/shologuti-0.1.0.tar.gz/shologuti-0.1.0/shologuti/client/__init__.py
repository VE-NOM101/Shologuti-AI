"""Client package containing the standalone Pygame interface."""


